﻿using System;

static class SharedInfoAndFunctions
{
    public static User Users { get; set; }
}